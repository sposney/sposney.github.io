(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-63d1477b-9d1a-4d3c-bfe8-c01687e43d7c .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b37396a3-6de1-40ff-9f41-2b6777afcf2f .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-cdcdc893-9d8b-4866-a0d7-6fa98cc59fef .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-1b21849b-d4c5-458b-bf77-dfcadccb4dc1 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-a57e3a45-2a2e-433c-8c12-b0a891704ed8 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-a9fcc731-f9ab-45a3-90a3-fcaa73a1c535 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b2b484d1-066a-442c-92cf-f8d98e5e7740 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);