(function(window, undefined) {

  var jimLinks = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Image_1" : [
        "5db73ee8-8351-4fcc-a2bc-de3d88ca2277"
      ]
    },
    "37fce076-ba9c-49f7-a4cb-68af508ae98c" : {
    },
    "5db73ee8-8351-4fcc-a2bc-de3d88ca2277" : {
      "Hotspot_1" : [
        "37fce076-ba9c-49f7-a4cb-68af508ae98c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);