function initData() {
  jimData.variables["Scroll position"] = "0";
  jimData.variables["Workout choice"] = "0";
  jimData.isInitialized = true;
}